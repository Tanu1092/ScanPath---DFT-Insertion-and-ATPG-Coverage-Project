// Simple 8-bit ALU used as the functional block in the DFT demonstration.
// Operation:
// 000 = ADD
// 001 = SUB
// 010 = AND
// 011 = OR
// 100 = XOR
// 101 = NOT A
// 110 = INC A
// 111 = DEC A
module alu_8bit (
    input  wire [7:0] a,
    input  wire [7:0] b,
    input  wire [2:0] op,
    output reg  [7:0] y,
    output reg        carry
);
    always @(*) begin
        y = 8'h00;
        carry = 1'b0;
        case (op)
            3'b000: {carry, y} = {1'b0,a} + {1'b0,b};
            3'b001: {carry, y} = {1'b0,a} - {1'b0,b};
            3'b010: y = a & b;
            3'b011: y = a | b;
            3'b100: y = a ^ b;
            3'b101: y = ~a;
            3'b110: {carry, y} = {1'b0,a} + 9'b1;
            3'b111: {carry, y} = {1'b0,a} - 9'b1;
            default: y = 8'h00;
        endcase
    end
endmodule
