// Scan D Flip-Flop
module scan_dff (
    input  wire clk,
    input  wire reset,
    input  wire d,
    input  wire scan_in,
    input  wire scan_enable,
    output reg  q
);
    always @(posedge clk or posedge reset) begin
        if (reset)
            q <= 1'b0;
        else if (scan_enable)
            q <= scan_in;
        else
            q <= d;
    end
endmodule
