`timescale 1ns/1ps

module dft_alu_tb;
    reg clk;
    reg reset;
    reg scan_enable;
    reg scan_in;
    reg [7:0] a, b;
    reg [2:0] op;

    wire scan_out;
    wire [7:0] y;
    wire carry;

    dft_alu_top dut (
        .clk(clk),
        .reset(reset),
        .scan_enable(scan_enable),
        .scan_in(scan_in),
        .a(a),
        .b(b),
        .op(op),
        .scan_out(scan_out),
        .y(y),
        .carry(carry)
    );

    always #5 clk = ~clk;

    task scan_shift;
        input [3:0] pattern;
        integer i;
        begin
            for (i = 3; i >= 0; i = i - 1) begin
                scan_in = pattern[i];
                @(posedge clk);
                #1;
                $display("SCAN: in=%b out=%b q=%b", scan_in, scan_out, dut.scan_q);
            end
        end
    endtask

    initial begin
        $dumpfile("dft_alu_tb.vcd");
        $dumpvars(0, dft_alu_tb);

        clk = 0;
        reset = 1;
        scan_enable = 0;
        scan_in = 0;
        a = 0;
        b = 0;
        op = 0;

        #12;
        reset = 0;

        // Functional ALU tests
        a = 8'h15; b = 8'h0A; op = 3'b000; #10;
        $display("ADD: A=%h B=%h Y=%h Carry=%b", a, b, y, carry);

        a = 8'h15; b = 8'h0A; op = 3'b010; #10;
        $display("AND: A=%h B=%h Y=%h", a, b, y);

        a = 8'h15; b = 8'h0A; op = 3'b011; #10;
        $display("OR : A=%h B=%h Y=%h", a, b, y);

        // Scan test
        scan_enable = 1;
        scan_shift(4'b1010);
        scan_enable = 0;

        #10;
        $display("DFT scan demonstration completed.");
        $finish;
    end
endmodule
