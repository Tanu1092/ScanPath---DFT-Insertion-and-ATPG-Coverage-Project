// 4-bit Scan Chain
module scan_chain (
    input  wire       clk,
    input  wire       reset,
    input  wire       scan_enable,
    input  wire       scan_in,
    output wire       scan_out,
    output wire [3:0] q
);
    scan_dff ff0 (.clk(clk), .reset(reset), .d(1'b0), .scan_in(scan_in), .scan_enable(scan_enable), .q(q[0]));
    scan_dff ff1 (.clk(clk), .reset(reset), .d(1'b0), .scan_in(q[0]),   .scan_enable(scan_enable), .q(q[1]));
    scan_dff ff2 (.clk(clk), .reset(reset), .d(1'b0), .scan_in(q[1]),   .scan_enable(scan_enable), .q(q[2]));
    scan_dff ff3 (.clk(clk), .reset(reset), .d(1'b0), .scan_in(q[2]),   .scan_enable(scan_enable), .q(q[3]));

    assign scan_out = q[3];
endmodule
