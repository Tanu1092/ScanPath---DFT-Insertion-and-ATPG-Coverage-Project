// DFT-enabled 8-bit ALU top module.
// In functional mode, ALU operates normally.
// In scan mode, internal scan registers can be shifted through scan_in/scan_out.
module dft_alu_top (
    input  wire       clk,
    input  wire       reset,
    input  wire       scan_enable,
    input  wire       scan_in,
    input  wire [7:0] a,
    input  wire [7:0] b,
    input  wire [2:0] op,
    output wire       scan_out,
    output wire [7:0] y,
    output wire       carry
);
    wire [3:0] scan_q;

    scan_chain u_scan (
        .clk(clk),
        .reset(reset),
        .scan_enable(scan_enable),
        .scan_in(scan_in),
        .scan_out(scan_out),
        .q(scan_q)
    );

    alu_8bit u_alu (
        .a(a),
        .b(b),
        .op(op),
        .y(y),
        .carry(carry)
    );
endmodule
